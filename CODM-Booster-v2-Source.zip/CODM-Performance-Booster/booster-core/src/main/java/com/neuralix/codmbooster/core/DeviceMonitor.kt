package com.neuralix.codmbooster.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.view.WindowManager

/** Thermal level: 0 = normal ... 6 = shutdown, -1 = not available. */
data class DeviceStatus(
    val availableRamMb: Long,
    val totalRamMb: Long,
    val lowMemory: Boolean,
    val thermalLevel: Int,
    val thermalLabel: String,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val batteryTempC: Float,
    val powerSaverOn: Boolean,
    val freeStorageGb: Double,
    val totalStorageGb: Double,
    val refreshRateHz: Int
)

data class CheckItem(
    val ok: Boolean,
    val title: String,
    val advice: String,
    val fix: Fix?
)

enum class Fix { BATTERY_SAVER, STORAGE, DISPLAY, RECENTS }

object DeviceMonitor {

    fun read(context: Context): DeviceStatus {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)

        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermalLevel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) power.currentThermalStatus else -1
        val thermalLabel = when (thermalLevel) {
            0 -> "Normal"
            1 -> "Light"
            2 -> "Moderate"
            3 -> "Severe"
            4 -> "Critical"
            5 -> "Emergency"
            6 -> "Shutdown"
            else -> "Not available"
        }

        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val tempC = (battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

        val stat = StatFs(Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024.0 * 1024.0

        @Suppress("DEPRECATION")
        val hz = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
            .defaultDisplay.refreshRate.toInt()

        return DeviceStatus(
            availableRamMb = mem.availMem / (1024L * 1024L),
            totalRamMb = mem.totalMem / (1024L * 1024L),
            lowMemory = mem.lowMemory,
            thermalLevel = thermalLevel,
            thermalLabel = thermalLabel,
            batteryPercent = percent,
            isCharging = charging,
            batteryTempC = tempC,
            powerSaverOn = power.isPowerSaveMode,
            freeStorageGb = stat.availableBytes / gb,
            totalStorageGb = stat.totalBytes / gb,
            refreshRateHz = hz
        )
    }

    /** Pre-game checklist. Each failed item lowers the readiness score. */
    fun checklist(s: DeviceStatus): List<CheckItem> = listOf(
        CheckItem(
            ok = s.thermalLevel <= 1,
            title = "Phone temperature: ${s.thermalLabel}" +
                if (s.batteryTempC > 0) " (battery ${"%.1f".format(s.batteryTempC)}°C)" else "",
            advice = "A hot phone slows itself down, which is the biggest cause of FPS drops. Let it cool, remove the case, or use a fan.",
            fix = null
        ),
        CheckItem(
            ok = !s.isCharging,
            title = if (s.isCharging) "Charging while playing" else "Not charging",
            advice = "Charging adds heat. Unplug if the phone gets warm during matches.",
            fix = null
        ),
        CheckItem(
            ok = !s.powerSaverOn,
            title = if (s.powerSaverOn) "Battery saver is ON" else "Battery saver is off",
            advice = "Battery saver limits CPU/GPU speed and caps FPS. Turn it off before playing.",
            fix = Fix.BATTERY_SAVER
        ),
        CheckItem(
            ok = s.batteryPercent < 0 || s.batteryPercent >= 20,
            title = "Battery: ${if (s.batteryPercent >= 0) "${s.batteryPercent}%" else "unknown"}",
            advice = "Many phones lower performance when the battery is low.",
            fix = null
        ),
        CheckItem(
            ok = s.freeStorageGb >= 3.0,
            title = "Free storage: ${"%.1f".format(s.freeStorageGb)} GB",
            advice = "Keep at least 3 GB free so the game can load maps and textures smoothly.",
            fix = Fix.STORAGE
        ),
        CheckItem(
            ok = !s.lowMemory && s.availableRamMb >= 1500,
            title = "Free RAM: ${s.availableRamMb} MB of ${s.totalRamMb} MB",
            advice = "Close apps you are not using from the recent-apps screen (swipe them away).",
            fix = Fix.RECENTS
        ),
        CheckItem(
            ok = s.refreshRateHz >= 90,
            title = "Screen refresh rate: ${s.refreshRateHz} Hz",
            advice = "If your phone supports 90/120 Hz, set it in Display settings so CODM can use higher frame rates.",
            fix = Fix.DISPLAY
        )
    )

    fun score(items: List<CheckItem>): Int {
        val weights = listOf(30, 10, 20, 10, 10, 15, 5)
        var score = 100
        items.forEachIndexed { i, item -> if (!item.ok) score -= weights.getOrElse(i) { 5 } }
        return score.coerceIn(0, 100)
    }

    /** Recommended in-game settings based on the phone's RAM. */
    fun recommendedSettings(s: DeviceStatus): String {
        val ramGb = s.totalRamMb / 1024.0
        return when {
            ramGb < 4.5 -> "Graphics Quality: LOW\nFrame Rate: HIGH\nTurn OFF: Depth of Field, Bloom, Real-time Shadows, Ragdoll, Water Reflection"
            ramGb < 7.5 -> "Graphics Quality: LOW or MEDIUM\nFrame Rate: VERY HIGH (or highest stable)\nTurn OFF: Depth of Field, Bloom, Real-time Shadows, Ragdoll"
            else -> "Graphics Quality: LOW for max FPS, MEDIUM if stable\nFrame Rate: MAX / ULTRA\nTurn OFF: Depth of Field, Bloom, Ragdoll"
        } + "\n\nSmooth beats pretty: pick the highest frame rate that stays steady without heating up."
    }
}
