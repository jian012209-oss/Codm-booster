package com.neuralix.codmbooster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.neuralix.codmbooster.core.CheckItem
import com.neuralix.codmbooster.core.DeviceMonitor
import com.neuralix.codmbooster.core.Fix

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0B0F14")
    private val card = Color.parseColor("#151B23")
    private val accent = Color.parseColor("#F5A623")
    private val good = Color.parseColor("#3DDC84")
    private val bad = Color.parseColor("#FF5A5A")
    private val fg = Color.parseColor("#E6EDF3")
    private val muted = Color.parseColor("#8B949E")

    private val codmPackages = listOf("com.activision.callofduty.shooter", "com.garena.game.codm")

    private lateinit var scoreText: TextView
    private lateinit var scoreLabel: TextView
    private lateinit var checklistBox: LinearLayout
    private lateinit var settingsText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 3000)
        }
    }

    private val dp get() = resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ---------- UI ----------

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(28))
            setBackgroundColor(bg)
        }

        root.addView(label("CODM BOOSTER", 24f, accent, bold = true))
        root.addView(label("Pre-game check to keep your phone cool and your FPS steady.", 13f, muted).apply {
            setPadding(0, px(4), 0, px(16))
        })

        // Score card
        val scoreCard = cardView().apply { gravity = Gravity.CENTER_HORIZONTAL }
        scoreCard.addView(label("READINESS", 12f, muted, bold = true).apply { gravity = Gravity.CENTER })
        scoreText = label("--", 56f, good, bold = true).apply { gravity = Gravity.CENTER }
        scoreLabel = label("", 14f, fg).apply { gravity = Gravity.CENTER }
        scoreCard.addView(scoreText)
        scoreCard.addView(scoreLabel)
        root.addView(scoreCard)

        root.addView(primaryButton("▶  PLAY CODM") { launchCodm() })

        // Checklist
        root.addView(section("CHECKLIST  (updates every 3 s)"))
        checklistBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(checklistBox)

        // Recommended settings
        root.addView(section("RECOMMENDED IN-GAME SETTINGS"))
        val settingsCard = cardView()
        settingsText = label("", 14f, fg)
        settingsCard.addView(settingsText)
        settingsCard.addView(label("Set these in CODM → Settings → Audio & Graphics.", 12f, muted).apply {
            setPadding(0, px(8), 0, 0)
        })
        root.addView(settingsCard)

        // Shortcuts
        root.addView(section("QUICK FIXES"))
        root.addView(secondaryButton("Do Not Disturb (block pop-ups)") {
            openSettings("android.settings.ZEN_MODE_SETTINGS", Settings.ACTION_SOUND_SETTINGS)
        })
        root.addView(secondaryButton("Battery saver settings") { openFix(Fix.BATTERY_SAVER) })
        root.addView(secondaryButton("Display / refresh rate") { openFix(Fix.DISPLAY) })
        root.addView(secondaryButton("Free up storage") { openFix(Fix.STORAGE) })
        root.addView(secondaryButton("CODM app info (clear cache)") { openCodmInfo() })
        root.addView(secondaryButton("Wi-Fi settings") { openSettings(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_SETTINGS) })

        // Tips
        root.addView(section("TIPS"))
        val tipsCard = cardView()
        tipsCard.addView(label(TIPS, 14f, fg))
        root.addView(tipsCard)

        root.addView(label(LIMITS, 11f, muted).apply { setPadding(0, px(16), 0, 0) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(root)
        })
    }

    private fun refresh() {
        val status = DeviceMonitor.read(this)
        val items = DeviceMonitor.checklist(status)
        val score = DeviceMonitor.score(items)

        scoreText.text = "$score"
        val (color, msg) = when {
            score >= 85 -> good to "Ready to play"
            score >= 60 -> accent to "Okay — fix the red items for smoother FPS"
            else -> bad to "Expect FPS drops — fix the red items first"
        }
        scoreText.setTextColor(color)
        scoreLabel.text = msg

        checklistBox.removeAllViews()
        items.forEach { checklistBox.addView(checkRow(it)) }

        settingsText.text = DeviceMonitor.recommendedSettings(status)
    }

    private fun checkRow(item: CheckItem): LinearLayout {
        val row = cardView()
        row.addView(label((if (item.ok) "✓  " else "✗  ") + item.title, 15f,
            if (item.ok) good else bad, bold = true))
        if (!item.ok) {
            row.addView(label(item.advice, 13f, muted).apply { setPadding(0, px(4), 0, 0) })
            item.fix?.let { fix -> row.addView(smallButton("Fix") { openFix(fix) }) }
        }
        return row
    }

    // ---------- Actions ----------

    private fun launchCodm() {
        for (pkg in codmPackages) {
            packageManager.getLaunchIntentForPackage(pkg)?.let {
                startActivity(it)
                return
            }
        }
        toast("CODM is not installed.")
    }

    private fun openCodmInfo() {
        val pkg = codmPackages.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg == null) { toast("CODM is not installed."); return }
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (_: Exception) { toast("Could not open app info.") }
    }

    private fun openFix(fix: Fix) {
        when (fix) {
            Fix.BATTERY_SAVER -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS, Settings.ACTION_SETTINGS)
            Fix.STORAGE -> openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, Settings.ACTION_SETTINGS)
            Fix.DISPLAY -> openSettings(Settings.ACTION_DISPLAY_SETTINGS, Settings.ACTION_SETTINGS)
            Fix.RECENTS -> toast("Open your recent apps and swipe away the ones you don't need.")
        }
    }

    private fun openSettings(action: String, fallback: String) {
        try { startActivity(Intent(action)) }
        catch (_: Exception) {
            try { startActivity(Intent(fallback)) } catch (_: Exception) { toast("Settings could not be opened.") }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- View helpers ----------

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun section(title: String) = label(title, 12f, accent, bold = true).apply {
        setPadding(0, px(22), 0, px(8))
    }

    private fun rounded(color: Int, strokeColor: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = 14 * dp
        strokeColor?.let { setStroke(px(1), it) }
    }

    private fun cardView() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card)
        setPadding(px(16), px(14), px(16), px(14))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = px(10) }
    }

    private fun primaryButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s
        textSize = 17f
        setTypeface(null, Typeface.BOLD)
        setTextColor(Color.BLACK)
        background = rounded(accent)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(56)).apply {
            topMargin = px(6)
        }
    }

    private fun secondaryButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        textSize = 15f
        setTextColor(fg)
        background = rounded(card, Color.parseColor("#2A333D"))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(50)).apply {
            bottomMargin = px(8)
        }
    }

    private fun smallButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s
        textSize = 13f
        setTextColor(Color.BLACK)
        background = rounded(accent)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(px(90), px(38)).apply { topMargin = px(8) }
    }

    companion object {
        private const val TIPS =
            "• Turn on your phone's Game Mode / Game Space / Game Turbo.\n" +
            "• Don't play while charging if the phone heats up.\n" +
            "• Remove a thick case or use a cooling fan for long sessions.\n" +
            "• Use 5 GHz Wi-Fi and pick the lowest-ping server.\n" +
            "• Delete CODM maps and modes you don't play (in-game Download menu).\n" +
            "• Restart your phone before a long gaming session."

        private const val LIMITS =
            "This app never touches CODM's files or memory, so it is safe for your account. " +
            "Android doesn't let normal apps overclock, force-close other apps, or lock FPS, " +
            "so it focuses on the things that actually cause lag: heat, battery saver, storage and RAM."
    }
}
